<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Our Services
     <?php $__env->endSlot(); ?>


    <div>
        <?php if (isset($component)) { $__componentOriginalff9615640ecc9fe720b9f7641382872b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff9615640ecc9fe720b9f7641382872b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banner','data' => ['title' => ' Our Services','page' => 'Services']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ' Our Services','page' => 'Services']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff9615640ecc9fe720b9f7641382872b)): ?>
<?php $attributes = $__attributesOriginalff9615640ecc9fe720b9f7641382872b; ?>
<?php unset($__attributesOriginalff9615640ecc9fe720b9f7641382872b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff9615640ecc9fe720b9f7641382872b)): ?>
<?php $component = $__componentOriginalff9615640ecc9fe720b9f7641382872b; ?>
<?php unset($__componentOriginalff9615640ecc9fe720b9f7641382872b); ?>
<?php endif; ?>
    </div>


    <section class="bg-[#fafaff]">
        <div class="container-x">
            <div class="max-w-[600px] px-6 py-[50px] m-auto text-center text-xl ">
                <p class="fadeIn">Samm Cooper Security Services system expertise and field experience enables us to apply
                    our
                    <span class="gradient-text">Defense/IT/Security Solutions</span> into virtually any environment -
                    from small businesses to large
                    enterprises.
                </p>
                <p class="fadeIn">By viewing and assessing our clients' requirements carefully, we design, install and
                    maintain cost
                    effect
                    Defense/IT/Security Systems achieve and exceed our clients' prospects.
                </p>
            </div>
        </div>
    </section>

    


    <section class="my-[50px] sm:my-[100px]">
        <div class="container-x">
            <div class="grid sm:grid-cols-2 md:grid-cols-3 gap-3 mb-3">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginale804957ecdb153e8c822de5ed47a4ace = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale804957ecdb153e8c822de5ed47a4ace = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.service-card','data' => ['title' => ''.e($service['title']).'','lead' => ''.e($service['lead']).'','imageUrl' => ''.e($service['images'][0]['url']).'','slug' => ''.e($service['slug']).'','icon' => ''.e($service['icon']).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('service-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e($service['title']).'','lead' => ''.e($service['lead']).'','imageUrl' => ''.e($service['images'][0]['url']).'','slug' => ''.e($service['slug']).'','icon' => ''.e($service['icon']).'']); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale804957ecdb153e8c822de5ed47a4ace)): ?>
<?php $attributes = $__attributesOriginale804957ecdb153e8c822de5ed47a4ace; ?>
<?php unset($__attributesOriginale804957ecdb153e8c822de5ed47a4ace); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale804957ecdb153e8c822de5ed47a4ace)): ?>
<?php $component = $__componentOriginale804957ecdb153e8c822de5ed47a4ace; ?>
<?php unset($__componentOriginale804957ecdb153e8c822de5ed47a4ace); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>


        </div>
    </section>

    <section class="pb-[50px]">

        <div class="container-x">


            <div class="max-w-[700px] m-auto">
                <header class="my-6 ">
                    <h4 class="text-sm sm:text-base font-semibold tracking-tight  text-primary uppercase mb-2">
                        Application Environment</h4>
                    <h2 class="text-3xl sm:text-5xl  font-bold">Secure, integrated, threat-defense setup.</h2>
                </header>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 application">
                    <ul class="list-none space-y-2 ">
                        <li class="flex items-center text-sm">
                            <div
                                class="w-6 h-6 flex items-center justify-center rounded-full bg-red-200 text-red-800 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                    <path
                                        d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z" />
                                </svg>
                            </div>
                            Governmental Organizations
                        </li>
                        <li class="flex items-center text-sm">
                            <div
                                class="w-6 h-6 flex items-center justify-center rounded-full bg-red-200 text-red-800 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                    <path
                                        d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z" />
                                </svg>
                            </div>
                            Military Bases and Installations
                        </li>
                        <li class="flex items-center text-sm">
                            <div
                                class="w-6 h-6 flex items-center justify-center rounded-full bg-red-200 text-red-800 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                    <path
                                        d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z" />
                                </svg>
                            </div>
                            Oil and Gas Industries
                        </li>
                        <li class="flex items-center text-sm">
                            <div
                                class="w-6 h-6 flex items-center justify-center rounded-full bg-red-200 text-red-800 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                    <path
                                        d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z" />
                                </svg>
                            </div>
                            Production and Manufacturing Industries
                        </li>
                        <li class="flex items-center text-sm">
                            <div
                                class="w-6 h-6 flex items-center justify-center rounded-full bg-red-200 text-red-800 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                    <path
                                        d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z" />
                                </svg>
                            </div>
                            Hotels
                        </li>
                        <li class="flex items-center text-sm">
                            <div
                                class="w-6 h-6 flex items-center justify-center rounded-full bg-red-200 text-red-800 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                    <path
                                        d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z" />
                                </svg>
                            </div>
                            Traffic Monitoring - Highway | Road | Bridges
                        </li>
                        <li class="flex items-center text-sm">
                            <div
                                class="w-6 h-6 flex items-center justify-center rounded-full bg-red-200 text-red-800 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                    <path
                                        d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z" />
                                </svg>
                            </div>
                            Airports | Seaports
                        </li>
                    </ul>
                    <ul class="list-none space-y-2">
                        <li class="flex items-center text-sm">
                            <div
                                class="w-6 h-6 flex items-center justify-center rounded-full bg-red-200 text-red-800 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                    <path
                                        d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z" />
                                </svg>
                            </div>
                            Financial Institutions
                        </li>
                        <li class="flex items-center text-sm">
                            <div
                                class="w-6 h-6 flex items-center justify-center rounded-full bg-red-200 text-red-800 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                    <path
                                        d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z" />
                                </svg>
                            </div>
                            Warehouses | Storage Facilities
                        </li>
                        <li class="flex items-center text-sm">
                            <div
                                class="w-6 h-6 flex items-center justify-center rounded-full bg-red-200 text-red-800 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                    <path
                                        d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z" />
                                </svg>
                            </div>
                            Chemical and Laboratory Facilities
                        </li>
                        <li class="flex items-center text-sm">
                            <div
                                class="w-6 h-6 flex items-center justify-center rounded-full bg-red-200 text-red-800 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                    <path
                                        d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z" />
                                </svg>
                            </div>
                            Hospitals
                        </li>
                        <li class="flex items-center text-sm">
                            <div
                                class="w-6 h-6 flex items-center justify-center rounded-full bg-red-200 text-red-800 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                    <path
                                        d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z" />
                                </svg>
                            </div>
                            Small | Medium Scale Businesses
                        </li>
                        <li class="flex items-center">
                            <div
                                class="w-6 h-6 flex items-center justify-center rounded-full bg-red-200 text-red-800 mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                    <path
                                        d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425z" />
                                </svg>
                            </div>
                            Residential
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    </section>

    


    <script>
        gsap.registerPlugin(ScrollTrigger)


        // gsap.from(".header", {
        //     scrollTrigger: {
        //         trigger: ".header",
        //     },
        //     autoAlpha: 0,
        // });

        ScrollTrigger.batch(".card-animation", {
            onEnter: elements => {
                gsap.from(elements, {
                    autoAlpha: 0,
                    y: 60,
                    stagger: 0.15,
                    delay: 0.5,
                });
            },
            once: true,
        });

        ScrollTrigger.batch(".application li", {
            onEnter: elements => {
                gsap.from(elements, {
                    autoAlpha: 0,
                    x: 10,
                    stagger: 0.15,
                    delay: 0.5,
                });
            },
            once: true,
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/sammy/resources/views/pages/services.blade.php ENDPATH**/ ?>