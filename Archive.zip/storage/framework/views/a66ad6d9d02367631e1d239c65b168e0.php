<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        About Us
     <?php $__env->endSlot(); ?>


    <div>
        <?php if (isset($component)) { $__componentOriginalff9615640ecc9fe720b9f7641382872b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff9615640ecc9fe720b9f7641382872b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banner','data' => ['title' => 'About us','page' => 'About']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'About us','page' => 'About']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff9615640ecc9fe720b9f7641382872b)): ?>
<?php $attributes = $__attributesOriginalff9615640ecc9fe720b9f7641382872b; ?>
<?php unset($__attributesOriginalff9615640ecc9fe720b9f7641382872b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff9615640ecc9fe720b9f7641382872b)): ?>
<?php $component = $__componentOriginalff9615640ecc9fe720b9f7641382872b; ?>
<?php unset($__componentOriginalff9615640ecc9fe720b9f7641382872b); ?>
<?php endif; ?>
    </div>

    <section>
        <div class="container-x py-[50px] ">

            <div class="flex flex-col sm:flex-row sm:w-[70%] m-auto  gap-[40px]">
                <div class="flex-1">
                    <header class=" mb-4">
                        <span class="uppercase text-sm trigger">About Us</span>
                        
                    </header>

                    <div class="text-base fadeIn">
                        <h2 class="font-semibold gradient-text text-3xl ">Precision is Our Watchword; Resilience is
                            Our
                            Virtue
                        </h2>
                        <p class="text-[#7c7c7c] ">
                            Samm Cooper Security Services Limited is a fast growing Defense, IT and Security Solutions
                            firm
                            offering customized, enterprise and supported solutions to all establishments which include
                            large- scale, governmental, small-medium scale and even start-up firms.
                        </p>
                        <p class="text-[#7c7c7c] ">By forging alliances with top vendors and equipment
                            manufacturers, and
                            investing strongly in
                            our
                            workforce, Samm Cooper Security Services Limited is able to provide solutions that integrate
                            the
                            best technology and security options that support purchase and implementation decisions.
                        </p>
                        <p class="text-[#7c7c7c] ">Our satisfied serviced clients depends on us for best-of-breed
                            systems, engineering
                            integration,
                            training and support. With our propriety SCS® methodology, we are able to provide our
                            clients
                            with a customized backend provisioning and maintenance for the enterprise.
                        </p>
                    </div>
                </div>
                <div class=" display w-full flex-1 overflow-clip ">
                    <div class="image-slide-down h-0 overflow-hidden origin-top">
                        <img lazy src="<?php echo e(asset('images/img2.png')); ?>" />
                    </div>
                </div>
            </div>



        </div>
    </section>


    


    <section class="sm:py-[50px] sm:p-[100px] py-[50px] fadeIn bg-[#fafaff]">
        <div class="container-x">
            <div class="sm:w-[720px] m-auto text-center">
                <h4 class="text-sm sm:text-base font-semibold tracking-tight  text-primary uppercase mb-2">
                    The Future</h4>
                <h2 class="text-3xl sm:text-5xl font-bold tracking-tighter mb-3 gradient-text">A message from our
                    director
                </h2>


                <p class="text-lg text-gray">
                    <img class="inline-block skew-x-2 rotate-y " src=<?php echo e(asset('/images/quote-img.png')); ?>

                        alt="Quote">
                    Samm Cooper Security Services Limited is very optimistic and will continue to grow as a valued
                    organization in the West African Sub-region.
                    Partnering with some of the worldwide leaders and manufacturers of Defense, IT and Security Systems,
                    we foresee an incredible growth and success in this field.
                    In the current point in our history, it is the attitude and commitment of our staff at Samm Cooper
                    Security Services that enables us to cope and adapt to various developments and to be recognized as
                    a major force within the Defense/IT/Security Industry.
                    <img class="inline-block" src=<?php echo e(asset('/images/quote-img.png')); ?> alt="Quote">

                </p>
            </div>

        </div>
    </section>


    <section class="py-[50px] sm:p-[100px]">
        <div class="container-x">
            <header>
                <h2 class="text-sm sm:text-base font-semibold tracking-tight  text-primary uppercase mb-2">Our Strategic
                    Partners
                </h2>
            </header>
        </div>


        <div class=" mt-[50px] w-full overflow-x-hidden">
            <div class="mq flex p-2 w-[1000%] sm:w-[300%]" id="mq">
                <div id="mq-content" class=" flex w-full items-center">
                    <div class=" min-w-[200px] max-w-[300px] px-5">
                        <img src=<?php echo e(asset('images/brands/b0.webp')); ?> alt="panasonic">
                    </div>
                    <div class=" min-w-[200px] max-w-[300px] px-5">
                        <img src=<?php echo e(asset('images/brands/b1.webp')); ?> alt="panasonic">
                    </div>

                    <div class=" min-w-[200px] max-w-[300px] px-5">
                        <img src=<?php echo e(asset('images/brands/b2.jpg')); ?> alt="panasonic">
                    </div>
                    <div class=" min-w-[200px] max-w-[300px] px-5">
                        <img src=<?php echo e(asset('images/brands/b3.png')); ?> alt="panasonic">
                    </div>

                    <div class=" min-w-[200px] max-w-[300px] px-5">
                        <img src=<?php echo e(asset('images/brands/b4.png')); ?> alt="panasonic">
                    </div>
                    <div class=" min-w-[200px] max-w-[300px] px-5">
                        <img src=<?php echo e(asset('images/brands/b5.png')); ?> alt="panasonic">
                    </div>
                    <div class=" min-w-[200px] max-w-[300px] px-5">
                        <img src=<?php echo e(asset('images/brands/b6.png')); ?> alt="panasonic">
                    </div>
                    <div class=" min-w-[200px] max-w-[300px] px-5">
                        <img src=<?php echo e(asset('images/brands/b7.png')); ?> alt="panasonic">
                    </div>
                    <div class=" min-w-[200px] max-w-[300px] px-5">
                        <img src=<?php echo e(asset('images/brands/b8.png')); ?> alt="panasonic">
                    </div>
                </div>



            </div>

        </div>
    </section>




    <script>
        const mq = document.querySelector('#mq')
        const content = document.querySelector('#mq-content')
        const c = content.cloneNode(true)
        mq.append(c)

        const distance = -1 * c.clientWidth;

        gsap.fromTo(
            mq.children, {
                x: 0
            }, {
                x: distance,
                duration: 20,
                ease: 'none',
                repeat: -1
            }
        )


        // console.log(c.clientWidth);
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/sammy/resources/views/pages/about.blade.php ENDPATH**/ ?>