<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <link rel="stylesheet" type="text/css" href="/css/highslide.css" />
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e($service['title']); ?>

     <?php $__env->endSlot(); ?>


    <div>
        <?php if (isset($component)) { $__componentOriginalff9615640ecc9fe720b9f7641382872b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff9615640ecc9fe720b9f7641382872b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banner','data' => ['title' => ''.e(isset($service['short']) ? $service['short'] : $service['title']).'','page' => ''.e($service['title']).'','middleText' => 'Services','middleLink' => ''.e(route('services')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => ''.e(isset($service['short']) ? $service['short'] : $service['title']).'','page' => ''.e($service['title']).'','middleText' => 'Services','middleLink' => ''.e(route('services')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff9615640ecc9fe720b9f7641382872b)): ?>
<?php $attributes = $__attributesOriginalff9615640ecc9fe720b9f7641382872b; ?>
<?php unset($__attributesOriginalff9615640ecc9fe720b9f7641382872b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff9615640ecc9fe720b9f7641382872b)): ?>
<?php $component = $__componentOriginalff9615640ecc9fe720b9f7641382872b; ?>
<?php unset($__componentOriginalff9615640ecc9fe720b9f7641382872b); ?>
<?php endif; ?>
    </div>

    <section class="bg-[#fafaff] py-[50px] sm:py-[100px]">
        <div class="container-x">
            
            <div class="max-w-[640px] m-auto text-[#7c7c7c] fadeIn">
                <?php echo $service['description']; ?>

            </div>
        </div>
    </section>

    <section class="my-[50px] sm:my-[100px]">
        <div class="container-x">
            <div class=" max-w-[900px] m-auto">
                
                <div class="grid grid-cols-2 highslide-gallery gap-4">
                    <?php $__currentLoopData = $service['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="w-full h-[300px ] border card-animation">
                            <a class="h-full" href="<?php echo e($item['url']); ?>" class="highslide"
                                onclick="return hs.expand(this)">
                                <img class="w-full h-full object-contain" src="<?php echo e($item['url']); ?>" alt="Highslide JS"
                                    title="Click to enlarge" />
                            </a>


                            <div class="highslide-caption">
                                <?php echo e($item['caption']); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
    </section>


    


    
    <script type="text/javascript" src="<?php echo e(asset('js/highslide-with-gallery.min.js')); ?>"></script>


    <script type="text/javascript">
        hs.graphicsDir = '../highslide/graphics/';
        hs.align = 'center';
        hs.transitions = ['expand', 'crossfade'];
        hs.outlineType = 'glossy-dark';
        hs.wrapperClassName = 'dark';
        hs.fadeInOut = true;
        hs.dimmingOpacity = 0.75;

        // Add the controlbar
        if (hs.addSlideshow) hs.addSlideshow({
            //slideshowGroup: 'group1',
            interval: 5000,
            repeat: false,
            useControls: true,
            fixedControls: 'fit',
            overlayOptions: {
                opacity: .6,
                position: 'bottom center',
                hideOnMouseOut: true
            }
        });

        gsap.registerPlugin(ScrollTrigger)


        ScrollTrigger.batch(".card-animation", {
            onEnter: elements => {
                gsap.from(elements, {
                    autoAlpha: 0,
                    y: 60,
                    stagger: 0.15,
                    delay: 0.5,
                });
            },
            once: true,
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/sammy/resources/views/pages/services/show.blade.php ENDPATH**/ ?>