<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'imageUrl', 'lead', 'slug', 'icon']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'imageUrl', 'lead', 'slug', 'icon']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>


<div class="bg-[#F7F9FC] service-card card-animation">
    <div class="display w-full bg-red-100 relative  ">
        <div class="overflow-hidden">
            <a href="<?php echo e(route('service-details', ['slug' => $slug])); ?>">
                <img class="object-cover w-full h-[240px]  service-image" src=<?php echo e($imageUrl); ?> alt={z $title }}>
            </a>
        </div>

        <div class="box-image absolute bottom-[-50px] center-h ">
            <img src="<?php echo e(asset("images/$icon")); ?>" class="h-[52px] w-[52px] service-icon" alt=<?php echo e($title); ?>>
        </div>
    </div>
    <div class="text-center mt-[50px] py-10 px-4">
        <h4 class="text-xl font-bold"><?php echo $title; ?></h4>
        <p class="text-base text-[#7c7c7c] line-clamp"><?php echo $lead; ?></p>

        <a class="gradient-text flex justify-center items-center gap-2"
            href="<?php echo e(route('service-details', ['slug' => $slug])); ?>">Learn More
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                stroke="#db2d1b" class="size-6">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17.25 8.25 21 12m0 0-3.75 3.75M21 12H3" />
            </svg>

        </a>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/sammy/resources/views/components/service-card.blade.php ENDPATH**/ ?>