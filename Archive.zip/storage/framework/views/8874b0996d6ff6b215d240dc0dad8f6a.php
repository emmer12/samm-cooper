<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <link rel="stylesheet" type="text/css" href="/css/highslide.css" />
     <?php $__env->slot('title', null, []); ?> 
        Surveillance - [CCTV]
     <?php $__env->endSlot(); ?>


    <div>
        <?php if (isset($component)) { $__componentOriginalff9615640ecc9fe720b9f7641382872b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff9615640ecc9fe720b9f7641382872b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banner','data' => ['title' => 'Surveillance - [CCTV]','page' => 'Surveillance - [CCTV]','middleText' => 'Services','middleLink' => ''.e(route('services')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Surveillance - [CCTV]','page' => 'Surveillance - [CCTV]','middleText' => 'Services','middleLink' => ''.e(route('services')).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff9615640ecc9fe720b9f7641382872b)): ?>
<?php $attributes = $__attributesOriginalff9615640ecc9fe720b9f7641382872b; ?>
<?php unset($__attributesOriginalff9615640ecc9fe720b9f7641382872b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff9615640ecc9fe720b9f7641382872b)): ?>
<?php $component = $__componentOriginalff9615640ecc9fe720b9f7641382872b; ?>
<?php unset($__componentOriginalff9615640ecc9fe720b9f7641382872b); ?>
<?php endif; ?>
    </div>

    <section class="bg-[#fafaff] py-[100px]">
        <div class="container-x">
            
            <div class="max-w-[640px] m-auto text-[#7c7c7c] fadeIn">
                <p class=" ">
                    At Samm Cooper Security Services our Hybrid Closed Circuit Television (CCTV) Systems are designed
                    specially for each application to target unique requirements.
                </p>
                <p>Therefore a broad range of cameras, recording servers and transmission options are available to best
                    suit a clients' specific needs.</p>
                <p>Cameras can include facilities to pan, tilt or zoom into target objects. Units can be selected to
                    operate in various environments, indoors or outdoors, from high light situations to use of infra-red
                    or thermal cameras for operating at night times even in complete darkness.</p>
            </div>
        </div>
    </section>

    <section class="my-[100px]">
        <div class="container-x">
            <div class=" max-w-[900px] m-auto">
                <header>
                    <h2 class="gradient-text text-xl font-bold">CCD Cameras
                        Dome Cameras
                        Pinhole | Hidden Cameras Infra-red Cameras IP-Based Cameras Wireless Cameras
                        Speed Cameras</h2>
                </header>
                <br>
                <div class="grid grid-cols-3 highslide-gallery gap-4">
                    <div>
                        <a href=<?php echo e(asset('images/img4.jpg')); ?> class="highslide" onclick="return hs.expand(this)">
                            <img src=<?php echo e(asset('images/img4.jpg')); ?> alt="Highslide JS" title="Click to enlarge" />
                        </a>


                        <div class="highslide-caption">
                            Caption for the first image. This caption can be styled using CSS.
                        </div>
                    </div>
                    <div>
                        <a href=<?php echo e(asset('images/img4.jpg')); ?> class="highslide" onclick="return hs.expand(this)">
                            <img src=<?php echo e(asset('images/img4.jpg')); ?> alt="Highslide JS" title="Click to enlarge" />
                        </a>


                        <div class="highslide-caption">
                            Caption for the first image. This caption can be styled using CSS.
                        </div>
                    </div>
                    <div>
                        <a href=<?php echo e(asset('images/img4.jpg')); ?> class="highslide" onclick="return hs.expand(this)">
                            <img src=<?php echo e(asset('images/img4.jpg')); ?> alt="Highslide JS" title="Click to enlarge" />
                        </a>


                        <div class="highslide-caption">
                            Caption for the first image. This caption can be styled using CSS.
                        </div>
                    </div>
                </div>
            </div>
    </section>


    


    
    <script type="text/javascript" src="<?php echo e(asset('js/highslide-with-gallery.min.js')); ?>"></script>


    <script type="text/javascript">
        hs.graphicsDir = '../highslide/graphics/';
        hs.align = 'center';
        hs.transitions = ['expand', 'crossfade'];
        hs.outlineType = 'glossy-dark';
        hs.wrapperClassName = 'dark';
        hs.fadeInOut = true;
        hs.dimmingOpacity = 0.75;

        // Add the controlbar
        if (hs.addSlideshow) hs.addSlideshow({
            //slideshowGroup: 'group1',
            interval: 5000,
            repeat: false,
            useControls: true,
            fixedControls: 'fit',
            overlayOptions: {
                opacity: .6,
                position: 'bottom center',
                hideOnMouseOut: true
            }
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/sammy/resources/views/pages/services/cctv.blade.php ENDPATH**/ ?>