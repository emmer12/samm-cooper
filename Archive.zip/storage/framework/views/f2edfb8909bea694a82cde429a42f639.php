<button
    <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'bg-gradient-to-r from-[#db2d1b] to-[#3c2a99] text-white text-[14px] font-semibold py-2 px-4 rounded transition duration-300 ease-in-out hover:opacity-80'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/sammy/resources/views/components/primary-button.blade.php ENDPATH**/ ?>