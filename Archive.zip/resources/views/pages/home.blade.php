<x-app-layout>
    <x-slot:title>
        Home
    </x-slot>

    <x-hero-2></x-hero-2>
</x-app-layout>
