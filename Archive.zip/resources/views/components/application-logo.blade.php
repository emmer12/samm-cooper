<img {{ $attributes }} src="{{ asset('/images/logo.jpg') }}" alt="">
